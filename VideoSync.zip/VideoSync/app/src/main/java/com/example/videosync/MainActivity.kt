package com.example.videosync

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.lifecycleScope
import androidx.compose.material3.LinearProgressIndicator
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class MainActivity : ComponentActivity() {

    private lateinit var player: ExoPlayer
    private lateinit var client: ButtplugClient
    private lateinit var sync: SyncEngine

    private var status by mutableStateOf("Non connecté")
    private var devices by mutableStateOf<List<BpDevice>>(emptyList())
    private var selected by mutableStateOf<BpDevice?>(null)
    private var actions by mutableStateOf<List<FunscriptAction>>(emptyList())
    private var scriptName by mutableStateOf("aucun")
    private var videoName by mutableStateOf("aucune")
    private var videoUri by mutableStateOf<Uri?>(null)
    private var analysisMode by mutableStateOf(AnalysisMode.INTENSITY)
    private var analysisProgress by mutableStateOf<Float?>(null) // null = pas d'analyse en cours
    private var analysisJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        player = ExoPlayer.Builder(this).build()
        client = ButtplugClient(
            onStatus = { runOnUiThread { status = it } },
            onDevices = { list ->
                runOnUiThread {
                    devices = list
                    if (selected == null || list.none { it.index == selected?.index }) {
                        selected = list.firstOrNull()
                    }
                }
            }
        )
        sync = SyncEngine(player, client, lifecycleScope)

        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) { Screen() }
            }
        }
    }

    @Composable
    private fun Screen() {
        var intensity by remember { mutableStateOf(0.7f) }

        val pickVideo = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) {
                player.setMediaItem(MediaItem.fromUri(uri))
                player.prepare()
                videoName = uri.lastPathSegment ?: "vidéo"
                videoUri = uri
            }
        }
        val pickScript = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) {
                runCatching {
                    val text = contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
                    actions = FunscriptParser.parse(text)
                    scriptName = "${actions.size} points chargés"
                }.onFailure { scriptName = "fichier invalide : ${it.message}" }
            }
        }

        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("VideoSync", style = MaterialTheme.typography.headlineSmall)

            AndroidView(
                factory = { ctx -> PlayerView(ctx).apply { this.player = this@MainActivity.player } },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp)
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { pickVideo.launch(arrayOf("video/*")) }) { Text("Vidéo") }
                OutlinedButton(onClick = { pickScript.launch(arrayOf("*/*")) }) { Text("Script") }
            }
            Text("Vidéo : $videoName · Script : $scriptName")

            Text("Analyse automatique", style = MaterialTheme.typography.titleMedium)
            AnalysisMode.values().forEach { m ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = analysisMode == m, onClick = { analysisMode = m })
                    Text(m.label)
                }
            }
            val progress = analysisProgress
            if (progress != null) {
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                Text("Analyse en cours : ${(progress * 100).toInt()} %")
                OutlinedButton(onClick = { analysisJob?.cancel() }) { Text("Annuler l'analyse") }
            } else {
                Button(
                    enabled = videoUri != null,
                    onClick = { startAnalysis() }
                ) { Text("Analyser la vidéo") }
            }

            Text("Appareil", style = MaterialTheme.typography.titleMedium)
            Text(status)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { client.connect() }) { Text("Connecter") }
                OutlinedButton(onClick = { client.startScanning() }) { Text("Chercher") }
            }
            devices.forEach { d ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = selected?.index == d.index, onClick = { selected = d })
                    Text(d.name)
                }
            }

            Text("Intensité maximale : ${(intensity * 100).toInt()} %")
            Slider(
                value = intensity,
                onValueChange = {
                    intensity = it
                    sync.maxIntensity = it.toDouble()
                }
            )

            Button(
                enabled = selected != null && actions.isNotEmpty(),
                onClick = {
                    sync.maxIntensity = intensity.toDouble()
                    sync.start(selected!!, actions)
                    player.play()
                }
            ) { Text("Lancer la synchronisation") }

            OutlinedButton(onClick = {
                player.pause()
                sync.stop()
            }) { Text("Arrêt") }
        }
    }

    private fun startAnalysis() {
        val uri = videoUri ?: return
        sync.stop()
        player.pause()
        analysisProgress = 0f
        analysisJob = lifecycleScope.launch {
            try {
                val result = VideoAnalyzer.analyze(this@MainActivity, uri, analysisMode) {
                    runOnUiThread { analysisProgress = it }
                }
                actions = result
                scriptName = if (result.isEmpty()) {
                    "analyse sans résultat (peu de mouvement détecté)"
                } else {
                    "${result.size} points (analyse automatique)"
                }
            } catch (e: CancellationException) {
                scriptName = "analyse annulée"
            } catch (e: Exception) {
                scriptName = "analyse impossible : ${e.message}"
            } finally {
                analysisProgress = null
            }
        }
    }

    override fun onStop() {
        super.onStop()
        player.pause()
        sync.stop()
    }

    override fun onDestroy() {
        sync.stop()
        client.disconnect()
        player.release()
        super.onDestroy()
    }
}
