package com.example.videosync

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicInteger

/** Un appareil détecté par Intiface (ex. un JoyHub). */
data class BpDevice(
    val index: Int,
    val name: String,
    val scalarCount: Int,   // nombre de moteurs de vibration/rotation
    val linearCount: Int    // nombre d'axes linéaires (va-et-vient)
)

/**
 * Client minimal du protocole Buttplug (spec v3) via WebSocket.
 * Il parle à Intiface Central, qui gère le Bluetooth et les protocoles
 * propres à chaque marque (dont JoyHub).
 */
class ButtplugClient(
    private val onStatus: (String) -> Unit,
    private val onDevices: (List<BpDevice>) -> Unit
) {
    private val http = OkHttpClient()
    private var socket: WebSocket? = null
    private val msgId = AtomicInteger(1)
    private val devices = mutableMapOf<Int, BpDevice>()

    val isConnected: Boolean get() = socket != null

    fun connect(url: String = "ws://127.0.0.1:12345") {
        disconnect()
        val request = Request.Builder().url(url).build()
        socket = http.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                send(
                    "RequestServerInfo",
                    JSONObject()
                        .put("ClientName", "VideoSync")
                        .put("MessageVersion", 3)
                )
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                handle(text)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                socket = null
                onStatus("Connexion impossible : ${t.message}. Intiface Central est-il lancé (serveur démarré) ?")
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                socket = null
                onStatus("Déconnecté")
            }
        })
        onStatus("Connexion à Intiface…")
    }

    fun disconnect() {
        socket?.close(1000, null)
        socket = null
        devices.clear()
    }

    fun startScanning() = send("StartScanning", JSONObject())
    fun stopScanning() = send("StopScanning", JSONObject())
    fun stopAll() = send("StopAllDevices", JSONObject())

    /** Vibration / rotation : intensité entre 0.0 et 1.0 sur tous les moteurs. */
    fun setScalar(device: BpDevice, level: Double) {
        if (device.scalarCount == 0) return
        val scalars = JSONArray()
        for (i in 0 until device.scalarCount) {
            scalars.put(
                JSONObject()
                    .put("Index", i)
                    .put("Scalar", level.coerceIn(0.0, 1.0))
                    .put("ActuatorType", "Vibrate")
            )
        }
        send("ScalarCmd", JSONObject().put("DeviceIndex", device.index).put("Scalars", scalars))
    }

    /** Mouvement linéaire : aller à la position (0.0–1.0) en durationMs. */
    fun setLinear(device: BpDevice, position: Double, durationMs: Int) {
        if (device.linearCount == 0) return
        val vectors = JSONArray()
        for (i in 0 until device.linearCount) {
            vectors.put(
                JSONObject()
                    .put("Index", i)
                    .put("Duration", durationMs.coerceAtLeast(1))
                    .put("Position", position.coerceIn(0.0, 1.0))
            )
        }
        send("LinearCmd", JSONObject().put("DeviceIndex", device.index).put("Vectors", vectors))
    }

    private fun send(type: String, body: JSONObject) {
        body.put("Id", msgId.getAndIncrement())
        val msg = JSONArray().put(JSONObject().put(type, body))
        socket?.send(msg.toString())
    }

    private fun handle(text: String) {
        val arr = JSONArray(text)
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            when {
                obj.has("ServerInfo") -> {
                    onStatus("Connecté à Intiface")
                    send("RequestDeviceList", JSONObject())
                }
                obj.has("DeviceList") -> {
                    devices.clear()
                    val list = obj.getJSONObject("DeviceList").getJSONArray("Devices")
                    for (j in 0 until list.length()) addDevice(list.getJSONObject(j))
                    onDevices(devices.values.toList())
                }
                obj.has("DeviceAdded") -> {
                    addDevice(obj.getJSONObject("DeviceAdded"))
                    onDevices(devices.values.toList())
                }
                obj.has("DeviceRemoved") -> {
                    devices.remove(obj.getJSONObject("DeviceRemoved").getInt("DeviceIndex"))
                    onDevices(devices.values.toList())
                }
                obj.has("Error") -> {
                    onStatus("Erreur Intiface : " + obj.getJSONObject("Error").optString("ErrorMessage"))
                }
            }
        }
    }

    private fun addDevice(d: JSONObject) {
        val msgs = d.optJSONObject("DeviceMessages")
        val scalar = msgs?.optJSONArray("ScalarCmd")?.length() ?: 0
        val linear = msgs?.optJSONArray("LinearCmd")?.length() ?: 0
        val index = d.getInt("DeviceIndex")
        devices[index] = BpDevice(index, d.optString("DeviceName", "Appareil $index"), scalar, linear)
    }
}
