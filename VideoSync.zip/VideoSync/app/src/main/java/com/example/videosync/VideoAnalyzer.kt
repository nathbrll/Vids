package com.example.videosync

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.roundToInt

/** Ce que l'analyse extrait de la vidéo pour construire le script. */
enum class AnalysisMode(val label: String) {
    /** Plus il y a de mouvement à l'écran, plus la valeur est haute (vibration). */
    INTENSITY("Intensité du mouvement"),

    /** Hauteur de la zone qui bouge à l'écran (va-et-vient vertical). */
    VERTICAL("Position verticale")
}

/**
 * Analyse automatique d'une vidéo : compare des images successives pour
 * mesurer le mouvement, puis le convertit en liste d'actions (comme un funscript).
 *
 * L'analyse est approximative : elle suit le mouvement global de l'image,
 * pas un sujet précis. Un script préparé reste plus fiable.
 */
object VideoAnalyzer {

    private const val SAMPLE_W = 48
    private const val SAMPLE_H = 48
    private const val STEP_MS = 100L          // une mesure toutes les 100 ms (10 images/s)
    private const val PIXEL_THRESHOLD = 20    // écart de luminosité pour compter un pixel comme "en mouvement"

    suspend fun analyze(
        context: Context,
        uri: Uri,
        mode: AnalysisMode,
        onProgress: (Float) -> Unit
    ): List<FunscriptAction> = withContext(Dispatchers.Default) {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            val durationMs = retriever
                .extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: error("Durée de la vidéo introuvable")

            val times = ArrayList<Long>()
            val signal = ArrayList<Double>()

            var previous: IntArray? = null
            var lastCentroid = 0.5
            var t = 0L
            while (t < durationMs) {
                ensureActive()
                val frame = grabFrame(retriever, t)
                if (frame != null) {
                    val gray = toGray(frame)
                    frame.recycle()
                    val prev = previous
                    if (prev != null) {
                        var changed = 0
                        var weightSum = 0.0
                        var weightedY = 0.0
                        for (y in 0 until SAMPLE_H) {
                            for (x in 0 until SAMPLE_W) {
                                val i = y * SAMPLE_W + x
                                val diff = abs(gray[i] - prev[i])
                                if (diff > PIXEL_THRESHOLD) {
                                    changed++
                                    weightSum += diff
                                    weightedY += diff * y
                                }
                            }
                        }
                        val energy = changed / (SAMPLE_W * SAMPLE_H).toDouble()
                        if (weightSum > 0) {
                            lastCentroid = 1.0 - (weightedY / weightSum) / (SAMPLE_H - 1)
                        }
                        times.add(t)
                        signal.add(if (mode == AnalysisMode.INTENSITY) energy else lastCentroid)
                    }
                    previous = gray
                }
                t += STEP_MS
                onProgress((t.toFloat() / durationMs).coerceIn(0f, 1f))
            }

            buildActions(times, signal)
        } finally {
            retriever.release()
        }
    }

    private fun grabFrame(r: MediaMetadataRetriever, timeMs: Long): Bitmap? {
        val us = timeMs * 1000
        return if (Build.VERSION.SDK_INT >= 27) {
            r.getScaledFrameAtTime(us, MediaMetadataRetriever.OPTION_CLOSEST, SAMPLE_W, SAMPLE_H)
        } else {
            r.getFrameAtTime(us, MediaMetadataRetriever.OPTION_CLOSEST)?.let {
                Bitmap.createScaledBitmap(it, SAMPLE_W, SAMPLE_H, true).also { s -> if (s !== it) it.recycle() }
            }
        }
    }

    private fun toGray(bmp: Bitmap): IntArray {
        val scaled = if (bmp.width == SAMPLE_W && bmp.height == SAMPLE_H) bmp
        else Bitmap.createScaledBitmap(bmp, SAMPLE_W, SAMPLE_H, true)
        val px = IntArray(SAMPLE_W * SAMPLE_H)
        scaled.getPixels(px, 0, SAMPLE_W, 0, 0, SAMPLE_W, SAMPLE_H)
        if (scaled !== bmp) scaled.recycle()
        return IntArray(px.size) {
            val c = px[it]
            val r = (c shr 16) and 0xFF
            val g = (c shr 8) and 0xFF
            val b = c and 0xFF
            (0.299 * r + 0.587 * g + 0.114 * b).roundToInt()
        }
    }

    /** Lisse le signal, le normalise entre 0 et 100, puis en fait des actions. */
    private fun buildActions(times: List<Long>, raw: List<Double>): List<FunscriptAction> {
        if (raw.size < 3) return emptyList()

        // lissage : moyenne glissante sur 3 mesures
        val smooth = DoubleArray(raw.size) { i ->
            val a = raw[maxOf(0, i - 1)]
            val b = raw[i]
            val c = raw[minOf(raw.size - 1, i + 1)]
            (a + b + c) / 3.0
        }

        // normalisation robuste : on ignore les 5 % de valeurs les plus extrêmes
        val sorted = smooth.sorted()
        val lo = sorted[(sorted.size * 0.05).toInt()]
        val hi = sorted[(sorted.size * 0.95).toInt().coerceAtMost(sorted.size - 1)]
        val range = (hi - lo).takeIf { it > 1e-6 } ?: return emptyList()

        return smooth.indices.map { i ->
            val v = ((smooth[i] - lo) / range).coerceIn(0.0, 1.0)
            FunscriptAction(times[i], (v * 100).roundToInt())
        }
    }
}
