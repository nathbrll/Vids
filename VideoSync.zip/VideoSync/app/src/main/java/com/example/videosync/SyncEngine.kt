package com.example.videosync

import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Lit la position de la vidéo en continu et envoie à l'appareil la commande
 * correspondante du script. Fonctionne pour la vibration (intensité = position)
 * et pour les appareils linéaires (va-et-vient).
 */
class SyncEngine(
    private val player: ExoPlayer,
    private val client: ButtplugClient,
    private val scope: CoroutineScope
) {
    private var job: Job? = null
    private var nextIndex = 0

    /** Intensité maximale (0.0–1.0), pour garder le contrôle côté utilisateur. */
    @Volatile var maxIntensity: Double = 0.7

    fun start(device: BpDevice, actions: List<FunscriptAction>) {
        stop()
        if (actions.isEmpty()) return
        job = scope.launch(Dispatchers.Default) {
            var lastPlaying = false
            while (isActive) {
                val playing = player.isPlaying
                if (!playing) {
                    if (lastPlaying) client.stopAll()
                    lastPlaying = false
                    delay(50)
                    continue
                }
                if (!lastPlaying) {
                    // reprise ou déplacement dans la vidéo : on repart du bon point
                    val now = runOnMain { player.currentPosition }
                    nextIndex = actions.indexOfFirst { it.atMs >= now }.let { if (it < 0) actions.size else it }
                    lastPlaying = true
                }
                val now = runOnMain { player.currentPosition }
                while (nextIndex < actions.size && actions[nextIndex].atMs <= now + 30) {
                    val action = actions[nextIndex]
                    val nextAt = actions.getOrNull(nextIndex + 1)?.atMs ?: (action.atMs + 300)
                    val duration = (nextAt - action.atMs).toInt().coerceIn(30, 3000)
                    val level = action.pos / 100.0
                    if (device.linearCount > 0) {
                        client.setLinear(device, level * maxIntensity, duration)
                    } else {
                        client.setScalar(device, level * maxIntensity)
                    }
                    nextIndex++
                }
                delay(15)
            }
        }
    }

    fun stop() {
        job?.cancel()
        job = null
        client.stopAll()
    }

    private suspend fun <T> runOnMain(block: () -> T): T =
        kotlinx.coroutines.withContext(Dispatchers.Main) { block() }
}
