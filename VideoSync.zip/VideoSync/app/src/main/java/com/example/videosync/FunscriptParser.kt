package com.example.videosync

import org.json.JSONObject

/** Un point du script : à `atMs` millisecondes, position `pos` entre 0 et 100. */
data class FunscriptAction(val atMs: Long, val pos: Int)

object FunscriptParser {
    /** Lit un fichier .funscript (JSON avec une liste "actions" d'objets {at, pos}). */
    fun parse(json: String): List<FunscriptAction> {
        val actions = JSONObject(json).getJSONArray("actions")
        val result = ArrayList<FunscriptAction>(actions.length())
        for (i in 0 until actions.length()) {
            val a = actions.getJSONObject(i)
            result.add(FunscriptAction(a.getLong("at"), a.getInt("pos").coerceIn(0, 100)))
        }
        return result.sortedBy { it.atMs }
    }
}
