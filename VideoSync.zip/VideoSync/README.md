# VideoSync

App Android qui lit une vidéo et reproduit ses mouvements sur un appareil
Bluetooth **JoyHub**, en synchronisation avec un script de mouvement (`.funscript`).

## Comment ça marche

```
VideoSync (cette app)  --WebSocket-->  Intiface Central  --Bluetooth-->  appareil JoyHub
```

- **Intiface Central** (app gratuite, open source) gère le Bluetooth et le protocole
  JoyHub. VideoSync lui envoie des commandes au format Buttplug.
- Le **script** `.funscript` contient les positions (0–100) en fonction du temps.
  VideoSync lit la position de la vidéo et envoie la commande au bon moment.

## Installation

1. Installer **Intiface Central** sur le téléphone, puis y démarrer le serveur
   (port 12345 par défaut).
2. Allumer l'appareil JoyHub (le mettre en mode appairage, sans l'avoir connecté
   à l'app JoyHub en même temps : un appareil BLE n'accepte qu'une connexion).
3. Ouvrir le dossier du projet dans **Android Studio**, laisser Gradle se synchroniser,
   puis lancer l'app sur le téléphone.

### Obtenir l'APK sans Android Studio (GitHub)

1. Crée un compte GitHub gratuit, puis un nouveau dépôt (privé si tu préfères).
2. Envoie-y tout le contenu du dossier `VideoSync` (bouton *Add file > Upload files*),
   y compris le dossier caché `.github`.
3. Onglet **Actions** : la compilation démarre toute seule (2 à 5 minutes).
4. Ouvre l'exécution terminée, section **Artifacts**, télécharge **VideoSync-apk**
   (un zip contenant `app-debug.apk`).
5. Envoie l'APK sur ton téléphone et installe-le (autorise « sources inconnues »).

## Utilisation

1. **Connecter** : se connecte à Intiface Central.
2. **Chercher** : détecte l'appareil (il apparaît dans la liste, à sélectionner).
3. **Vidéo** : choisir la vidéo, puis soit **Script** (fichier `.funscript` existant),
   soit **Analyser la vidéo** pour générer le script automatiquement :
   - *Intensité du mouvement* : plus ça bouge à l'écran, plus la valeur monte (adapté à la vibration).
   - *Position verticale* : suit la hauteur de la zone qui bouge (adapté au va-et-vient).
   L'analyse prend du temps (de l'ordre de la durée de la vidéo selon le téléphone) et peut être annulée.
4. Régler l'**intensité maximale**, puis **Lancer la synchronisation**.
5. **Arrêt** coupe immédiatement l'appareil. La mise en arrière-plan de l'app l'arrête aussi.

## Limites actuelles

- L'analyse automatique suit le mouvement global de l'image (différences entre images
  successives), pas un sujet précis : elle est approximative, et un `.funscript`
  préparé reste plus fiable. Elle marche mieux avec une caméra fixe.
- L'app parle le protocole Buttplug v3. Si Intiface refuse la connexion, la version
  du protocole est à ajuster dans `ButtplugClient.kt`.
- Si l'appareil n'apparaît pas dans Intiface, son modèle n'est pas encore supporté
  par Buttplug : l'app ne peut pas le piloter.
- Le code n'a pas été compilé ni testé sur un vrai appareil ici.
